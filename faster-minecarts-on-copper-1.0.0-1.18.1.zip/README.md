# Faster Minecarts on Copper Blocks

Minecarts are faster when moving over rails that are placed on copper blocks.